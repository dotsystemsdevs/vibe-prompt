public class Problem_4 {
    public static void main(String[] args) {
        double a = 1.5;
        double b = 15;
        char c = 'u';
        double d = a + c;

        System.out.println (a);
        System.out.println (b);
        System.out.println (c);
        System.out.println (d);
    }
}

/*
 * Fil: Problem_4.java
 * Författare: 26dioh01
 * Datum: 2026-02-19
 */