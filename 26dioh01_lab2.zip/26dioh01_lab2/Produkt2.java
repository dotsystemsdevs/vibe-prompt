/*
 * Fil: Produkt2.java
 * Författare: 26dioh01
 * Datum: 2026-02-19
 */
 
 public class Produkt2 {
    public static void main(String[] args) {
        long k = 5;
        long product = 1;
        int i = 0;
        
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);
        i = i + 1;
        product = product * (k + i);

        System.out.println(product);
    }
}