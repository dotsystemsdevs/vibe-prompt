/*
 * Fil: Problem_3.java
 * Författare: 26dioh01
 * Datum: 2026-02-19
 */
 
 public class Problem_3
{
    public static void main (String[] args)
    {
        System.out.println ("Utskrift 1: ");
        System.out.println (5 / 2);
        System.out.println ("Utskrift 2: ");
        System.out.println (5.0 / 2);
    }
}