/*
 * Fil: Teckenrad.java
 * Författare: 26dioh01
 * Datum: 2026-02-19
 */
 
 public class Teckenrad {
    public static void main(String[] args) {
        System.out.println("a b c d e f g h i j");
    }
}