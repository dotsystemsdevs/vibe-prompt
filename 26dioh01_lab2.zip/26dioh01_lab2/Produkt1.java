/*
 * Fil: Produkt1.java
 * Författare: 26dioh01
 * Datum: 2026-02-19
 */
 
 public class Produkt1 {
    public static void main(String[] args) {
        int product = 1;
		
        product = product * 1;
        product = product * 2;
        product = product * 3;
        product = product * 4;
        product = product * 5;
        product = product * 6;
        product = product * 7;
        product = product * 8;
        product = product * 9;
        product = product * 10;

        System.out.println(product);
    }
}