/*
 * Fil: Circle.java
 * Författare: 26dioh01
 * Datum: 2026-03-05
 */

import java.util.Scanner;

public class Circle {
    public static void main (String[] args) {
        if (args.length == 0) {
            return;
        }

        double r = 0;
        String rString = args[0];
        Scanner rReader = new Scanner (rString);

        if (!rReader.hasNextDouble()) {
            System.out.println ("Decimal number expected!");
            return;
        }

        r = rReader.nextDouble ();

        double area = Math.PI * r * r;
        double circumference = 2 * Math.PI * r;

        System.out.println ("A=" + area);
        System.out.println ("C=" + circumference);
        
        rReader.close();
    }
}