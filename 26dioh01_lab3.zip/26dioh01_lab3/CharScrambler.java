/*
 * Fil: CharScrambler.java
 * Författare: 26dioh01
 * Datum: 2026-03-05
 */

public class CharScrambler {
    public static void main(String[] args) {
        if (args.length == 0) {
            return;
        }

        String text = args[0];

        if (text.length() != 9) {
            System.out.println("wrong number of characters: " + text.length());
            return;
        }

        System.out.print(text.charAt(8));
        System.out.print(text.charAt(0));
        System.out.print(text.charAt(7));
        System.out.print(text.charAt(1));
        System.out.print(text.charAt(6));
        System.out.print(text.charAt(2));
        System.out.print(text.charAt(5));
        System.out.print(text.charAt(3));
        System.out.println(text.charAt(4));
  
        if (text.startsWith("java")) {
            System.out.println("first characters: java");
        }
    }
}