/*
 * Fil: MathOps.java
 * Författare: 26dioh01
 * Datum: 2026-03-05
 */

import java.util.Scanner;

public class MathOps {
    public static void main (String[] args) {
        int a, b, c;

        if (args.length < 3) {
            return;
        }

        String aString = args[0];
        Scanner aReader = new Scanner (aString);
        String bString = args[1];
        Scanner bReader = new Scanner (bString);
        String cString = args[2];
        Scanner cReader = new Scanner (cString);

        if (aReader.hasNextInt()) {
            a = aReader.nextInt ();
        } else {
            System.out.println (aString + " - Integer number expected!");
            return;
        }

        if (bReader.hasNextInt()) {
            b = bReader.nextInt ();
        } else {
            System.out.println (bString + " - Integer number expected!");
            return;
        }

        if (cReader.hasNextInt()) {
            c = cReader.nextInt ();
        } else {
            System.out.println (cString + " - Integer number expected!");
            return;
        }

        if (a < b) {
            if (b < c) {
                c = c + 1;
            }
            a = (b + 5) * a;
        } else if (a > b) {
            if (a < c) {
                a = a + 1;
            } else {
                a = c + 3;
            }
        } else {
            c = c / (a + b);
        }

        int result = a + b + c;
        System.out.println(result);

        aReader.close();
        bReader.close();
        cReader.close();
    }
}