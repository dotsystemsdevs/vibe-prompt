/*
    Problem1_2
    Exempelprogram som används för att introducera kommandon
    javac och java.
    
    Peter Jenke, Peter.Jenke@hig.se
    2025-01-10
*/

public class Problem1_2
{
    public static void main (String[] args)
    {
        System.out.println ("26dioh01 2026-01-19");
    }
}