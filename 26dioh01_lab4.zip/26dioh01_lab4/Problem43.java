/*
 * Fil: Problem43.java
 * Författare: 26dioh01
 * Datum: 2026-04-02
 */
public class Problem43 {
    public static String createCharLine(char c, int nbr) {
        StringBuilder sBuilder = new StringBuilder();
        for (int i = 0; i < nbr; i++) {
            sBuilder.append(c);
        }
        return sBuilder.toString();
    }

    public static void main(String[] args) {
        String test1 = createCharLine('c', 5);
        System.out.println("Test 1 ('c', 5): " + test1);
        String test2 = createCharLine('*', 10);
        System.out.println("Test 2 ('*', 10): " + test2);
        String test3 = createCharLine('-', 20);
        System.out.println("Test 3 ('-', 20): " + test3);
    }
}