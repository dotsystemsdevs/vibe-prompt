/*
 * Fil: Problem41.java
 * Författare: 26dioh01
 * Datum: 2026-04-02
 */
public class Problem41 {
    public static void printStrings(String s0, String s1, String s2) {
        System.out.println(s0);
        System.out.println(s1);
        System.out.println(s2);
    }

    public static void main(String[] args) {
        String text1 = "one";
        String text2 = "two";
        String text3 = "three";
        printStrings(text1, text2, text3);
    }
}