/*
 * Fil: Problem42.java
 * Författare: 26dioh01
 * Datum: 2026-04-02
 */
public class Problem42 {
    public static int min(int i0, int i1, int i2) {
        int minsta = i0;
        if (i1 < minsta) {
            minsta = i1;
        }
        if (i2 < minsta) {
            minsta = i2;
        }
        return minsta;
    }

    public static int max(int i0, int i1, int i2) {
        int storsta = i0;
        if (i1 > storsta) {
            storsta = i1;
        }
        if (i2 > storsta) {
            storsta = i2;
        }
        return storsta;
    }

    public static void main(String[] args) {
        System.out.println("--- Ingående testning av Problem42 ---");
        System.out.println("Test (45, 12, 89): Min=" + min(45, 12, 89) + ", Max=" + max(45, 12, 89));
        System.out.println("Test (1, 2, 3):    Min=" + min(1, 2, 3) + ", Max=" + max(1, 2, 3));
        System.out.println("Test (3, 2, 1):    Min=" + min(3, 2, 1) + ", Max=" + max(3, 2, 1));
        System.out.println("Test (5, 5, 2):    Min=" + min(5, 5, 2) + ", Max=" + max(5, 5, 2));// Testfall 5: Alla värden är samma (7, 7, 7
        System.out.println("Test (7, 7, 7):    Min=" + min(7, 7, 7) + ", Max=" + max(7, 7, 7));
    }
}